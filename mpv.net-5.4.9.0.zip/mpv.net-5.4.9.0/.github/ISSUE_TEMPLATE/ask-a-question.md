---
name: Ask a question
about: Ask a question about mpv.net
title: ''
labels: question
assignees: stax76

---

This template is meant for usage questions of mpv.net.
